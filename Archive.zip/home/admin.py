from django.contrib import admin

# Register your models here.
from .models import UserLogin

# Register your model here
admin.site.register(UserLogin)